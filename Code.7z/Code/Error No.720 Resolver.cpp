#include <bits/stdc++.h>
#include <conio.h>
#include <Windows.h>
#define endl "\n"
using namespace std;

int main()
{
//	ios :: sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    CONSOLE_FONT_INFOEX cfi;
    cfi.cbSize = sizeof cfi;
    cfi.dwFontSize.X = 0;
    cfi.dwFontSize.Y = 30;  // �����С
    cfi.FontWeight = FW_DONTCARE; // �����ϸ����wingdi.hͷ�ļ���
    wcscpy_s(cfi.FaceName, L"Lucida Sans Writer");  // ����
    SetCurrentConsoleFontEx(GetStdHandle(STD_OUTPUT_HANDLE), FALSE, & cfi);
    system("color F0");
    cout << "This program can solve the error of error No.720 (network protocol failure)." << endl << endl;
    system("title Error No.720 Resolver");
    cout << "Step 1: Set the proxy\n";
    system("pause");
    system("set http_proxy=");
    system("set https_proxy=");
    cout << "Is it solved?(y, n)";
    char t = getch();
    cout << endl;
    if (t == 'y' || t == 'Y')
    {
        system("pause");
        return 0;
    }
    cout << endl;
    cout << "Step 2: Uninstall Device\n";
    cout << "After the pop-up window, right-click WAN Miniport (IP) in Network Adapter in Device Manager in System Tools and select Uninstall Device.\n";
    system("pause");
    system("compmgmt.msc");
    system("pause");
    cout << endl;
    cout << "Step 3: Restart the computer\n";
    cout << "The computer will restart automatically in 30 seconds." << endl;
    system("pause");
    system("shutdown -r -t 30 -c \"The computer will restart automatically in 30 seconds.\"");
    cout << "This is the last step." << endl;
    cout << "Please press: a means cancel, and other keys mean the program is closed." << endl;
    t = getch();
    if (t == 'a' || t == 'A')
        system("shutdown -a");
    system("pause");
    return 0;
}
